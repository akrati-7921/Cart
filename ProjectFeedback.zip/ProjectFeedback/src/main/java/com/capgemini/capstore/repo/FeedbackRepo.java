package com.capgemini.capstore.repo;

import com.capgemini.capstore.beans.Feedback;

public interface FeedbackRepo {
	public String addfeedback(Feedback fee);
}
