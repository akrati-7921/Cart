package com.capgemini.capstore.services;

import com.capgemini.capstore.beans.Feedback;

public interface FeedbackService {

	public String addfeedback(Feedback fee);
}
