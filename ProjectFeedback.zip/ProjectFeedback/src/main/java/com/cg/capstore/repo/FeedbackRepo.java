package com.cg.capstore.repo;

import com.cg.capstore.beans.Feedback;

public interface FeedbackRepo {
	public String addfeedback(Feedback fee);
}
