package com.cg.capstore.repo;

import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Feedback;

@Repository("frepo")
public class FeedbackRepoImpl implements FeedbackRepo{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String addfeedback(Feedback fee) {
		System.out.println(fee);
		Random ran=new Random();
		String fid="F#"+Integer.toString(ran.nextInt(100));
		fee.setFeedbackId(fid);
		entityManager.persist(fee);
		
		return fid;
	}

}
