package com.cg.capstore.repo;

public interface IInviteFriendRepo {

	public String inviteFriend(String mobileNo);
}
