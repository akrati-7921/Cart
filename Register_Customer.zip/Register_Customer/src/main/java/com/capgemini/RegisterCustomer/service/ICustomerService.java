package com.capgemini.RegisterCustomer.service;

import com.capgemini.RegisterCustomer.bean.Address;
import com.capgemini.RegisterCustomer.bean.Customer;
import com.capgemini.RegisterCustomer.bean.Merchant;

public interface ICustomerService {

	public Customer registerCustomer(Customer customer) ;
	public Address addAddress(Address address, String id);
}
